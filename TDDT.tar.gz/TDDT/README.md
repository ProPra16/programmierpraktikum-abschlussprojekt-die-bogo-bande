#ABSCHLUSS PROJEKT DER BOGO BANDE

[![Build Status](https://travis-ci.org/ProPra16/programmierpraktikum-abschlussprojekt-die-bogo-bande.svg?branch=master)](https://travis-ci.org/ProPra16/programmierpraktikum-abschlussprojekt-die-bogo-bande)

Siehe LIZENZ.txt

Programmiert von Sebastian Bischoff und Sven Gasterstädt

Quellen:

Thanks @Russintheus for the countdown sound
https://www.freesound.org/people/Russintheus/sounds/165089/

PlaySound Snippet from Andrew Jenkins on
http://stackoverflow.com/a/37693420
modified a few bits and bobs




